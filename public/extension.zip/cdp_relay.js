'use strict';

const PAGE_METHOD_DOMAINS = ["Page", "Runtime", "Network","Log","DOM","Overlay","Input","Emulation","Accessibility","Navigate"];


const updated_browser_version_result = {
    "protocolVersion": "1.3",
    "product": "Chrome/134.0.6998.35",
    "revision": "@ea6ef4c2ac15ae95d2cfd65682da62c093415099",
    "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "jsVersion": "13.4.114.14"
};
let sessionId = null;
let PROXY_WS_URL = null;
let targetWindowId = null;
let socket = null;
let autoAttach = false;
let tab_session_registry = []; // track attached tabs
let browserTargetInfo = {
  type: "browser",
  title: "",
  url: "",
  attached: true,
  canAccessOpener: false,
  targetId: "b8f93388-34cb-4de8-b071-c1b071711254"
};
let browserSessionId = "D4BD71B1F4DFE512ED1783FF02EDE0F7";
let BROWSER_CONTEXT_ID = "94F66902FFA1FEE58E89A2C3BC80DA7E";

// Export the initialization function
export function initCdpRelay() {
    chrome.windows.getCurrent((win) => {
        console.log("[Final Testing] Sidepanel: Window initialized", win.id);
        targetWindowId = win.id;
        chrome.runtime.sendMessage({
            type: "SIDE_PANEL_READY",
            windowId: win.id
        });
    });
    
    // Set up message listeners and other initialization code
    setupMessageListeners();
}

// Move the message listener to a separate function
function setupMessageListeners() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === "SET_ROOM_ID") {
            console.log("[Final Testing] Side panel received room ID:", message.roomId);
            PROXY_WS_URL = `ws://34.171.7.176:9223/extension?roomId=${message.roomId}`; 
            // Now process the session id as needed
            connectWebSocket();
            if (sendResponse) sendResponse({success: true});
        }
    });
}

function generate_random_session_id() {
  return [...Array(32)]
    .map(() => Math.floor(Math.random() * 16).toString(16).toUpperCase())
    .join('');
}

async function attach_to_tab(tabId, targetId) {
  // todo: what is the correct way to not try to attach again?
  return new Promise((resolve, reject) => {
    let count = 0;
    let sessionId = generate_random_session_id();
    if (tab_session_registry.some(entry => entry.tabId === tabId)) { // don't try to attach again if we know someone already attached to this tab
      count+=1;
      console.log("[Final Testing] Reusing existing attachment for tab:", tabId);
      tab_session_registry.push({ tabId, sessionId, targetId });
      resolve(sessionId);
    }
    else{
      chrome.debugger.attach({ tabId }, "1.3", () => {
        if (chrome.runtime.lastError) {
          console.error("[Final Testing] Failed to attach debugger:", chrome.runtime.lastError);
        }
        console.log("[Final Testing] Successfully attached to tab:", tabId);
        count+=1;
        tab_session_registry.push({ tabId, sessionId, targetId });
        resolve(sessionId);
      });
    }
  });
}
async function detach_from_tab(tabId) {
  return new Promise((resolve) => {
    chrome.debugger.detach({ tabId }, () => {
      if (chrome.runtime.lastError) {
        console.log("[Final Testing] Failed to detach debugger (possibly not attached):", chrome.runtime.lastError);
      }
      console.log("[Final Testing] Debugger detached from tab:", tabId);
      tab_session_registry = tab_session_registry.filter(t => t.tabId !== tabId); // remove all entries for this tab
      resolve();
    });
  });
}
async function simple_detach_from_target(targetId) {
  return new Promise((resolve) => {
    chrome.debugger.detach({targetId}, () => {
      if (chrome.runtime.lastError) {
        console.warn("Failed to detach debugger from target:", chrome.runtime.lastError);
      }
      console.log("Debugger detached from target", targetId);
      resolve();
    });
  });
}
async function detach_from_all_targets() {
  return new Promise((resolve) => {
    // Only detach tabs in the target window
    chrome.tabs.query({ windowId: targetWindowId }, async (tabs) => {
      for (const tab of tabs) {
        await detach_from_tab(tab.id);
      }
      resolve();
    });
  });
}

function add_fields_to_target(target) {
    return {
        ...target,
        targetId: target.id,
        attached: target.attached || true, // todo: this is a hack to always tell playwright that we are attached
        canAccessOpener: target.canAccessOpener || false,
        browserContextId: BROWSER_CONTEXT_ID,
    };
}

function connectWebSocket() {
    console.log("[Final Testing] Connecting to WebSocket:", PROXY_WS_URL);
    socket = new WebSocket(PROXY_WS_URL);

    socket.onopen = async () => {
        console.log("[Final Testing] Connected to WebSocket server");
        autoAttach = false;
        tab_session_registry = []; // todo, have a subscriptions field so that we can keep track of which sessions want what

        console.log("[Final Testing] Detaching from all targets in window", targetWindowId);
        await detach_from_all_targets();
        console.log("[Final Testing] Detached from all targets in window", targetWindowId);
        console.log("[Final Testing] Reattaching to all tabs in window", targetWindowId);

    };

    socket.onmessage = async (event) => {
        console.log("Received message:", event.data.substring(0, 100) + (event.data.length > 100 ? "..." : ""));
        
        const payload = JSON.parse(event.data);
        const method = payload.method;
        let result = null;
        
        if (method === "Browser.getVersion") {
            console.log("Processing Browser.getVersion");
            result = updated_browser_version_result;
        } else if (method.startsWith("Target.")) {
            let targets, notice_params, notice, request_session_id, targetId, sessionId, registry_entry, target_session_id;
            console.log("Processing Target method:", method);
            
            switch (method) {
                case "Target.attachToTarget": // ATTACH TO TARGET
                    request_session_id = payload.sessionId;
                    targetId = payload.params.targetId;
                    console.log("[Final Testing] Attaching to target:", targetId);
                    targets = await chrome.debugger.getTargets();
                    let target = targets.find(t => t.id === targetId);
                    let targetInfo = add_fields_to_target(target);
                    sessionId = await attach_to_tab(targetInfo.tabId, targetId);
                    result = { sessionId };
                    notice_params = { sessionId, targetInfo, waitingForDebugger: false };
                    notice = { method: "Target.attachedToTarget", params: notice_params, sessionId: request_session_id };
                    socket.send(JSON.stringify(notice));
                    
                    console.log("[Final Testing] Attached to target, session ID:", sessionId);
                    break;

                case "Target.detachFromTarget": // DETACH FROM TARGET
                    result = {};
                    request_session_id = payload.sessionId;
                    target_session_id = payload.params.sessionId;
                    console.log("[Final Testing] Detaching from target session:", target_session_id);
                    registry_entry = tab_session_registry.find(t => t.sessionId === target_session_id);
                    // if (!registry_entry) {
                    //   console.error("[Final Testing] Target.detachFromTarget: sessionId not found in registry");
                    //   throw new Error("Target.detachFromTarget: sessionId not found in registry");
                    // }
                    if (!registry_entry) {
                      console.warn("[Final Testing] Target.detachFromTarget: sessionId not found in registry. Likely already detached.");
                      
                      // Still send back a valid response so Playwright doesn't hang
                      const response = { id: payload.id, result: {} };
                      socket.send(JSON.stringify(response));
                      return;
                    }
                    tab_session_registry = tab_session_registry.filter(entry => entry.sessionId !== target_session_id); // remove this session from the registry
                    notice_params = { sessionId: target_session_id, targetId: registry_entry.targetId };
                    notice = { method: "Target.detachedFromTarget", params: notice_params, sessionId: request_session_id };
                    socket.send(JSON.stringify(notice));
                    console.log("[Final Testing] Detached from target session:", target_session_id);
                    break;
                    
                case "Target.attachToBrowserTarget": // ATTACH TO BROWSER TARGET
                    console.log("[Final Testing] Attaching to browser target");
                    if (payload.sessionId) {
                      console.error("[Final Testing] Calling attachToBrowserTarget with sessionId is not allowed");
                      throw new Error("Calling attachToBrowserTarget with sessionId is not allowed");
                    }
                    result = { sessionId: browserSessionId };
                    // send attachedToTarget event to playwright
                    notice_params = { sessionId: browserSessionId, targetInfo: browserTargetInfo, waitingForDebugger: false };
                    notice = { method: "Target.attachedToTarget", params: notice_params };
                    socket.send(JSON.stringify(notice));
                    console.log("[Final Testing] Attached to browser target, session ID:", browserSessionId);
                    break;
                    
                case "Target.getTargets": // GET TARGETS
                  console.log("[Final Testing] Getting targets, sessionId:", payload.sessionId);
                  if (!payload.sessionId) {
                    // Return only targets (tabs) in our target window.
                    targets = await chrome.debugger.getTargets();
                    let response_targets = targets.map(add_fields_to_target);
                    response_targets = response_targets.filter(t => t.type === "page");
                    result = { targetInfos: response_targets };
                    console.log("[Final Testing] Found", response_targets.length, "targets");
                  } else {
                    targets = await chrome.debugger.getTargets();
                    let response_targets = targets
                        .filter(t => t.type === "page" && t.tabId !== undefined)
                        .map(add_fields_to_target);

                    result = { targetInfos: response_targets };
                    console.log("[Final Testing] Found", response_targets.length, "targets with session ID");
                  }
                  break;
                  
                case "Target.getTargetInfo": // GET TARGET INFO (no params or sessionId)
                    console.log("[Final Testing] Getting target info, sessionId:", payload.sessionId);
                    if (!payload.sessionId) {
                        result = { targetInfo: browserTargetInfo };
                    } else {
                      console.error("[Final Testing] Calling getTargetInfo with sessionId is not allowed");
                      throw new Error("Calling getTargetInfo with sessionId is not allowed");
                    }
                    break;
                    
                case "Target.createTarget": // CREATE TARGET
                  console.log("[Final Testing] Creating target with URL:", payload.params.url);
                  const newTab = await chrome.tabs.create({ url: payload.params.url, windowId: targetWindowId })
                  // search for the new tab
                  targets = await chrome.debugger.getTargets();
                  const new_target = targets.find(t => t.tabId === newTab.id);
                  let new_targetInfo = add_fields_to_target(new_target);
                  result = { targetId: new_targetInfo.targetId };
                  
                  // Explicitly attach to the target after creation
                  sessionId = await attach_to_tab(newTab.id, new_targetInfo.targetId);
                  
                  // Send attached to target notification to playwright
                 notice_params = { sessionId, targetInfo: new_targetInfo, waitingForDebugger: true };
                  notice = { method: "Target.attachedToTarget", params: notice_params, sessionId: payload.sessionId };
                  socket.send(JSON.stringify(notice));
                  console.log("[Final Testing] Created target, ID:", new_targetInfo.targetId);
                  break;
                  
                case "Target.setAutoAttach": {
                  console.log("[Final Testing] Setting auto-attach, sessionId:", payload.sessionId);

                  if (!payload.sessionId) {
                    autoAttach = true;
                    // Automatically attach to all tabs in the target window
                    targets = await chrome.debugger.getTargets();
                    chrome.tabs.query({ windowId: targetWindowId }, async (tabs) => {
                      console.log("[Final Testing] Found", tabs.length, "tabs in the target window");
                      
                      // Filter targets to only include those in our target window
                      let targetInfos = targets
                        .filter(t => t.tabId && tabs.some(tab => tab.id === t.tabId))
                        .map(add_fields_to_target);
                      
                      for (const targetInfo of targetInfos) {
                        if (targetInfo.url.startsWith("chrome://") || 
                          targetInfo.url.startsWith("about:") ||
                            targetInfo.url.startsWith("devtools://")) {
                          console.log("[Final Testing] Skipping internal Chrome URL:", targetInfo.url);
                          continue;
                        }
                        await detach_from_tab(targetInfo.tabId);
                        sessionId = await attach_to_tab(targetInfo.tabId, targetInfo.targetId);
                        
                        console.log('[Final Testing] Auto-attached to target:', targetInfo.targetId);

                        notice_params = { sessionId, targetInfo, waitingForDebugger: false };
                        notice = { method: "Target.attachedToTarget", params: notice_params };
                        socket.send(JSON.stringify(notice));
                      }
                      
                      result = {};
                      const response = { id: payload.id, result: result };
                      socket.send(JSON.stringify(response));
                    });
                    return; // Return early since we're sending the response in the callback
                  } else {
                    console.warn("[Final Testing] Calling Target.setAutoAttach with sessionId is not supported");
                    result = {};
                  }
                  break;
                }
                
                default:
                    console.log("[Final Testing] Unknown Target method:", method);
                    result = {};
            }
        }
        else if (method === "Page.bringToFront") {
          console.log("[Final Testing] Processing Page.bringToFront");
          const registry_entry = tab_session_registry.find(t => t.sessionId === payload.sessionId);
          if (!registry_entry) {
            console.error("[Final Testing] Page.bringToFront: sessionId not found in registry", payload.sessionId);
            throw new Error("Page.bringToFront: sessionId not found in registry");
          }
          chrome.tabs.update(registry_entry.tabId, { active: true }, (tab) => {
            if (chrome.runtime.lastError) {
              console.error("[Final Testing] Failed to bring tab to front:", chrome.runtime.lastError);
            } else {
              console.log("[Final Testing] Tab brought to front:", registry_entry.tabId);
            }
          });
          result = {};
        }
        else if (PAGE_METHOD_DOMAINS.includes(method.split(".")[0])) {
          console.log("[Final Testing] Processing domain method:", method);
          let registry_entry = tab_session_registry.find(t => t.sessionId === payload.sessionId);
          // if (!registry_entry) {
          //   console.error("[Final Testing] Unknown method: sessionId not found in registry", payload.sessionId);
          //   throw new Error("Unknown method: sessionId not found in registry", payload.sessionId);
          // }
          if (!registry_entry) {
            console.warn("[Relay] sessionId not found in registry:", payload.sessionId, "Command:", method);
            
            // Gracefully handle missing session instead of throwing error
            socket.send(JSON.stringify({
              id: payload.id,
              sessionId: payload.sessionId,
              error: {
                code: -32000,
                message: "Session detached or no longer exists."
              }
            }));
            return; // Stop further processing
          }
          result = await chrome.debugger.sendCommand({ tabId: registry_entry.tabId }, method, payload.params);
        }
        else {
          console.log("[Final Testing] Unknown method:", method);
          result = {}
        }
       
        console.log("[Final Testing] Sending response for method:", method);
        const response = { "id": payload.id, "result": result }
        if (payload.sessionId) {  // keep the sessionId if present 
          response.sessionId = payload.sessionId;
        }
        socket.send(JSON.stringify(response));
    };

    socket.onclose = () => {
        console.log("[Final Testing] WebSocket closed. Reconnecting in 3 seconds...");
        setTimeout(connectWebSocket, 3000); // Auto-reconnect
    };

    socket.onerror = (error) => {
        console.error("[Final Testing] WebSocket error:", error);
    };
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  let registry_entries = tab_session_registry.filter(t => t.tabId === source.tabId);
  if (registry_entries.length > 1) {
    console.log("[Final Testing] Multiple registry entries found for tabId:", source.tabId);
  }
  for (const registry_entry of registry_entries) {
    console.log("[Final Testing] Forwarding debugger event:", method, "from tab:", source.tabId);
    let session_id = registry_entry.sessionId;
    let payload = {
      method: method,
      params: params,
      sessionId: session_id,
    }
    socket.send(JSON.stringify(payload));
  }
})

chrome.debugger.onDetach.addListener(async (source, reason) => {
  console.log("[Relay] Debugger detached from tab:", source.tabId, "Reason:", reason);

//TODO: IS THE RUN ENDED THEN SKIP THE REATTACH?
//   // Find sessions associated with this tab and explicitly remove them
  tab_session_registry = tab_session_registry.filter(entry => {
    if (entry.tabId === source.tabId) {
      console.log("[Relay] Removing session for detached tab:", source.tabId);

      // Explicitly notify Playwright of detachment immediately
      socket.send(JSON.stringify({
        method: "Target.detachedFromTarget",
        params: {
          sessionId: entry.sessionId,
          targetId: entry.targetId,
          reason: reason
        }
      }));
      return false; // remove from registry
    }
    return true;
  });

  chrome.debugger.getTargets(async (targets) => {
    const reattachTarget = targets.find(t => t.tabId === source.tabId && t.type === "page");
    if (!reattachTarget) {
      console.warn("[Relay] Could not find target for reattach after detach:", source.tabId);
      return;
    }
  
    try {
      // Detach just to be safe
      await detach_from_tab(source.tabId);
  
      const sessionId = await attach_to_tab(source.tabId, reattachTarget.id);
      const targetInfo = add_fields_to_target(reattachTarget);
  
      console.log("[Relay] Reattached to target:", reattachTarget.id, "with session:", sessionId);
  
      socket.send(JSON.stringify({
        method: "Target.attachedToTarget",
        params: {
          sessionId,
          targetInfo,
          waitingForDebugger: false
        }
      }));
    } catch (err) {
      console.error("[Relay] Error during auto-reattach after detach:", err);
    }
  });
});

