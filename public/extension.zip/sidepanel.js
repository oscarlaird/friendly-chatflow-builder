import { initCdpRelay } from './cdp_relay.js';
import CONFIG from './config.js';
// Function to initialize the sidepanel
function initSidepanel() {
    // Initialize CDP relay
    console.log("Sidepanel: Initializing CDP relay");
    initCdpRelay();
    console.log("Sidepanel: CDP relay initialized");
    // Get current window
    chrome.windows.getCurrent((window) => {
        const windowId = window.id;
        
        // Ask the background script for the window type
        chrome.runtime.sendMessage({type: "get-window-payload", windowId: windowId}, (response) => {
            const payload = response.payload;
            console.log("Sidepanel: Received window payload:", payload);
            
      
            // Create and append iframe based on window type
            if (payload.windowType) {
                let iframeSrc = null;
                
                if (payload.windowType === "CREATE_RECORDING_WINDOW") {
                    iframeSrc = CONFIG.windowUrls.RECORDING_WINDOW + "?chatId=" + payload.chatId;
                } else if (payload.windowType === "CREATE_AGENT_RUN_WINDOW") {
                    iframeSrc = CONFIG.windowUrls.AGENT_RUN_WINDOW + "?chatId=" + payload.chatId;
                }
                
                if (iframeSrc) {
                    const iframe = document.createElement('iframe');
                    iframe.src = iframeSrc;
                    iframe.style.width = '100%';
                    iframe.style.height = '100%';
                    iframe.style.border = 'none';
                    iframe.style.flex = '1';
                    
                    document.body.style.padding = '0';
                    document.body.style.margin = '0';
                    document.body.style.height = '100vh';
                    document.body.style.display = 'flex';
                    document.body.style.flexDirection = 'column';
                    
                    document.body.appendChild(iframe);
                } else {
                    const loadingDiv = document.createElement('div');
                    loadingDiv.style.padding = '8px';
                    loadingDiv.textContent = 'Loading...';
                    document.body.appendChild(loadingDiv);
                }
            } else {
                const loadingDiv = document.createElement('div');
                loadingDiv.style.padding = '8px';
                loadingDiv.textContent = 'Loading...';
                document.body.appendChild(loadingDiv);
            }
        });
    });
}

// Initialize when the document is loaded
document.addEventListener('DOMContentLoaded', initSidepanel);