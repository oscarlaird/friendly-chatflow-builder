// Configuration for window types and their corresponding URLs
const CONFIG = {
  // URLs for different window types
  windowUrls: {
    RECORDING_WINDOW: "https://preview--friendly-chatflow-builder.lovable.app",
    AGENT_RUN_WINDOW: "https://preview--friendly-chatflow-builder.lovable.app"
  },

  webappUrls: {
    LOCALHOST: "http://localhost:8081",
    PREVIEW: "https://preview--friendly-chatflow-builder.lovable.app"
  }
};

// Export the configuration
export default CONFIG; 