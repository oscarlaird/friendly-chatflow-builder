// Configuration for window types and their corresponding URLs
const CONFIG = {
  // URLs for different window types
  windowUrls: {
    RECORDING_WINDOW: "https://preview--friendly-chatflow-builder.lovable.app",
    AGENT_RUN_WINDOW: "https://app.macroagents.ai/agent_sidepanel"
  },

  webappUrls: {
    LOCALHOST: "http://localhost:8080",
    PREVIEW: "https://app.macroagents.ai"
  }
};

// Export the configuration
export default CONFIG; 