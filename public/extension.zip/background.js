// Import the configuration
import CONFIG from './config.js';
// import { createClient } from './supabase.js';
// import './background_agent.js';


let window_payload_map = new Map(); // Maps window IDs to their payload
// - payload.roomId is the message_id
// TODO: do we really need to use payload; can I just use a simple list of (window_id, message_id) pairs?
let run_id_to_window_id_map = new Map(); // Maps run IDs to window IDs

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Handle specific message types
    if (message.type === "CREATE_RECORDING_WINDOW" || message.type === "CREATE_AGENT_RUN_WINDOW") {
        console.log("Creating window of type:", message.type, "with payload:", message.payload);
        create_window(message.type, message.payload);
    } 
    
    else if (message.type === "JUMP_TO_AGENT_WINDOW") {
        console.log("BACKGROUND SCRIPT: Jumping to agent window");
        let roomId = message.payload.roomId;
        console.log("BACKGROUND SCRIPT: Run ID:", roomId);
        let window_id = run_id_to_window_id_map.get(roomId);
        console.log("BACKGROUND SCRIPT: Window ID:", window_id);
        if (window_id) {
            console.log("BACKGROUND SCRIPT: Focusing on window ID:", window_id);
            chrome.windows.update(window_id, { focused: true });
        }
    } else if (message.type === "SIDE_PANEL_READY") {
        // Side panel tells us it's ready
        let windowId = message.windowId;
        let payload = window_payload_map.get(windowId);
        if (payload && payload.roomId) {
          chrome.runtime.sendMessage({
            type: "SET_ROOM_ID",
            roomId: payload.roomId
          });
          console.log("Sent SET_ROOM_ID to side panel with roomId:", payload.roomId);
        } else {
          console.error("No payload/roomId found for window id:", windowId);
        }
      }
      else if (message.type === "TAKE_SCREENSHOT") {
        console.log("BACKGROUND SCRIPT: Taking screenshot");
        

        let windowId = run_id_to_window_id_map.get(message.payload.roomId);
        captureScreenshot(windowId, message.payload);
        
        // Acknowledge receipt
        sendResponse({ received: true });
        return true; // Indicates async response
      }
});

function captureScreenshot(windowId, payload) {
  console.log("BACKGROUND SCRIPT: Capturing screenshot windowId:", windowId, "payload:", payload);

  if (windowId === undefined) {
    // Send undefined screenshot result to webapp tabs
    chrome.tabs.query({}, function(tabs) {
      // Filter tabs that match any of the webapp URLs defined in config
      const webappTabs = tabs.filter(tab => {
        if (!tab.url) return false;
        
        // Check if the tab URL matches any of the webapp URLs in config
        return Object.values(CONFIG.webappUrls).some(url => 
          tab.url.includes(url)
        );
      });
      
      if (webappTabs.length === 0) {
        console.error("No webapp tabs found matching the configured URLs");
        return;
      }
      
      // Send the screenshot to all matching webapp tabs
      webappTabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'SCREENSHOT_RESULT',
          payload: {
            roomId: payload.roomId,
            screenshot: undefined
          }
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("Error sending screenshot to tab", tab.id, ":", chrome.runtime.lastError);
          } else {
            console.log("BACKGROUND SCRIPT: Screenshot sent successfully to tab", tab.id, "Response:", response);
          }
        });
      });
    });
    return;
  }
    chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, function(dataUrl) {
      if (chrome.runtime.lastError) {
        console.error("Screenshot error:", chrome.runtime.lastError);
        return;
      }
      
      // Get all tabs in the window
      chrome.tabs.query({}, function(tabs) {
        // Filter tabs that match any of the webapp URLs defined in config
        const webappTabs = tabs.filter(tab => {
          if (!tab.url) return false;
          
          // Check if the tab URL matches any of the webapp URLs in config
          return Object.values(CONFIG.webappUrls).some(url => 
            tab.url.includes(url)
          );
        });
        
        if (webappTabs.length === 0) {
          console.error("No webapp tabs found matching the configured URLs");
          return;
        }
        
        // Send the screenshot to all matching webapp tabs
        webappTabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'SCREENSHOT_RESULT',
            payload: {
              roomId: payload.roomId,
              screenshot: dataUrl
            }
          }, (response) => {
            if (chrome.runtime.lastError) {
              console.error("Error sending screenshot to tab", tab.id, ":", chrome.runtime.lastError);
            } else {
              console.log("BACKGROUND SCRIPT: Screenshot sent successfully to tab", tab.id, "Response:", response);
            }
          });
        });
      });
    });
  }

function create_window(window_type, payload) {
    payload.windowType = window_type;
    chrome.windows.create({
        focused: true,
        type: 'normal',
        state: 'maximized'
    },
    (window) => {
        window_payload_map.set(window.id, payload);
        // Open the side panel in the newly created window
        let run_id = payload.roomId;
        if (run_id) {
            run_id_to_window_id_map.set(run_id, window.id);
        }
        chrome.sidePanel.open({ windowId: window.id }, () => {
            if (chrome.runtime.lastError) {
                console.error("Failed to open side panel:", chrome.runtime.lastError);
            } else {
                console.log("Side panel opened in new window");
                
                // Send the chatId to the background_agent.js when the side panel is opened
               
            }
        });
    });
}

// Get the window ID of the current tab
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "get-window-payload") {
        console.log("Received message get-window-payload:", request, "from sender:", sender, "with window id:", request.windowId);
        sendResponse({ payload: window_payload_map.get(request.windowId) });
    }
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

// Listen for debugger disconnect events
chrome.debugger.onDetach.addListener((source, reason) => {
    console.log(`[DEBUGGER DEBUG] Debugger detached from tab ${source.tabId}, reason: ${reason}`);
    
    chrome.tabs.get(source.tabId, (tab) => {
      if (chrome.runtime.lastError) {
        console.error("Error getting tab info:", chrome.runtime.lastError);
        return;
      }
  
      if (window_payload_map.has(tab.windowId)) {
        console.log(`[DEBUGGER DEBUG] Scheduling debugger reattach for tab ${source.tabId}`);
  
        // Retry mechanism: attempt reattach every 3 seconds, up to 5 attempts
        let attempts = 0;
        const maxAttempts = 5;
  
        function tryReattach() {
          connectDebugger(source.tabId, (success) => {
            if (!success && attempts < maxAttempts) {
              attempts++;
              console.log(`[DEBUGGER DEBUG] Reattach attempt ${attempts} failed. Retrying in 3 seconds...`);
              setTimeout(tryReattach, 50);
            } else if (success) {
              console.log(`[DEBUGGER DEBUG] Successfully reattached debugger to tab ${source.tabId}`);
            } else {
              console.error(`[DEBUGGER DEBUG] Failed to reattach debugger to tab ${source.tabId} after ${maxAttempts} attempts.`);
            }
          });
        }
  
        // Initial retry
        setTimeout(tryReattach, 3000);
      }
    });
  });
  



// Modified to add callback parameter
function connectDebugger(tabId, callback) {
    console.log("[DEBUGGER DEBUG] Connecting debugger to tab:", tabId);
  
    chrome.debugger.getTargets((targets) => {
      const isAttached = targets.some(target => target.tabId === tabId && target.attached);
  
      if (isAttached) {
        console.log("[DEBUGGER DEBUG] Debugger already attached to tab:", tabId);
        callback(true);
        return;
      }
  
      chrome.debugger.attach({ tabId: tabId }, "1.3", () => {
        if (chrome.runtime.lastError) {
          console.error("Failed to attach debugger to tab", tabId, ":", chrome.runtime.lastError);
          callback(false);
          return;
        }
        console.log("[DEBUGGER DEBUG] Attached to tab:", tabId);
        
        chrome.debugger.sendCommand({ tabId }, "Debugger.enable", {}, () => {
          if (chrome.runtime.lastError) {
            console.error("Failed to enable Debugger domain:", chrome.runtime.lastError);
            callback(false);
            return;
          }
  
          chrome.debugger.sendCommand({ tabId }, "Runtime.runIfWaitingForDebugger", {}, () => {
            if (chrome.runtime.lastError) {
              console.error("Failed to run Runtime after enabling debugger:", chrome.runtime.lastError);
              callback(false);
            } else {
              console.log("Debugger resumed successfully on tab:", tabId);
              
              // Enable Network domain
              // TODO: what is going on here?
              chrome.debugger.sendCommand({ tabId }, "Network.enable", {}, () => {
                if (chrome.runtime.lastError) {
                  console.error("Failed to enable Network domain:", chrome.runtime.lastError);
                  callback(false);
                } else {
                  console.log("Network domain enabled on tab:", tabId);
                  callback(true);
                }
              });
            }
          });
        });
      });
    });
  }

// const WEB_APP_URL_FRAG = "preview--friendly-chatflow-builder.lovable.app"
const WEB_APP_URL_FRAG = "chatId"
async function getWebAppTabIds() {
  return new Promise((resolve) => {
    chrome.tabs.query({}, function(tabs) {
      // Filter tabs that contain the webapp URL fragment
      const webappTabs = tabs.filter(tab => {
        if (!tab.url) return false;
        return tab.url.includes(WEB_APP_URL_FRAG);
      });
      if (webappTabs.length === 0) {
        console.error(`No webapp tabs found containing '${WEB_APP_URL_FRAG}'`);
        resolve([]);
        return;
      }
      resolve(webappTabs.map(tab => tab.id));
    });
  });
}


chrome.windows.onRemoved.addListener(async function (windowId) {
  console.log("Window closed:", windowId);
  let payload = window_payload_map.get(windowId);
  let message_id = payload.roomId;
  console.log("Message ID:", message_id);
  let tabIds = await getWebAppTabIds();
  console.log("Tab IDs:", tabIds);
  if (tabIds.length === 0) {
    console.error("No webapp tabs found matching the configured URLs");
    return;
  }
  let firstTabId = tabIds[0];
  chrome.tabs.sendMessage(firstTabId, { type: "WINDOW_CLOSED_BY_USER", message_id: message_id }, (response) => { });
  console.log("Sent message to tab:", firstTabId);
});